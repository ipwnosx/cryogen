
// when this is loaded into the browser, 
// just use the defaults...

module.exports = function (name, defaults) {
  return defaults
}
