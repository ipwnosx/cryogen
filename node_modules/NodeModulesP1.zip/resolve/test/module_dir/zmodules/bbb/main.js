module.exports = function (n) { return n * 111; };
