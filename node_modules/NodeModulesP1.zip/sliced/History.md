
1.0.1 / 2015-07-14
==================

 * fixed; missing file introduced in 4f5cea1

1.0.0 / 2015-07-12
==================

 * Remove unnecessary files from npm package - #6 via joaquimserafim
 * updated readme stats

0.0.5 / 2013-02-05
==================

  * optimization: remove use of arguments [jkroso](https://github.com/jkroso)
  * add scripts to component.json [jkroso](https://github.com/jkroso)
  * tests; remove time for travis

0.0.4 / 2013-01-07
==================

  * added component.json #1 [jkroso](https://github.com/jkroso)
  * reversed array loop #1 [jkroso](https://github.com/jkroso)
  * remove fn params

0.0.3 / 2012-09-29
==================

  * faster with negative start args

0.0.2 / 2012-09-29
==================

  * support full [].slice semantics

0.0.1 / 2012-09-29
===================

  * initial release

